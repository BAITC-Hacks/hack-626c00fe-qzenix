import {randomUUID} from 'node:crypto';
import {z} from 'zod';
import type {Card, Session, Store, Task, Proposal, Milestone} from '../shared/types.js';
import {emptyCard,meaningful} from '../shared/domain.js';
import {AppError} from './errors.js';

const now=()=>new Date().toISOString();
const id=(prefix:string)=>prefix+'-'+randomUUID();
function check(condition:unknown,message:string,status=400):asserts condition {if(!condition)throw new AppError(status,message);}
export function cleanCard(input:unknown):Card {
  check(input && typeof input==='object' && !Array.isArray(input),'Карточка имеет неверный формат.');
  const card=emptyCard();
  for(const field of Object.keys(card) as (keyof Card)[]){
    const value=(input as Record<string,unknown>)[field];
    check(value==null || typeof value==='string','Некорректное поле карточки: '+field);
    card[field]=(value as string||'').trim();
    check(card[field].length<=(field==='title'?160:5000),'Слишком длинное поле: '+field);
  }
  return card;
}
function business(session:Session){check(session.role==='business','Это действие доступно представителю бизнеса.',403);}
function team(session:Session){check(session.role==='team','Это действие доступно команде.',403);}
export function findTask(state:Store,taskId:string):Task {const task=state.tasks.find(t=>t.id===taskId);check(task,'Задача не найдена.',404);return task;}
function owned(state:Store,session:Session,taskId:string):Task{business(session);const task=findTask(state,taskId);check(task.businessId===session.profileId,'Изменять можно только свои задачи.',403);return task;}
function revision(task:Task,value:unknown){check(value===task.revision,'Задача изменилась в другой вкладке. Обновите её перед сохранением.',409);}
export function createTask(state:Store,session:Session,body:any){
  business(session);const raw=z.string().trim().min(3,'Опишите потребность хотя бы одним предложением.').max(12000).parse(body.rawDescription);
  const task:Task={id:id('task'),businessId:session.profileId,rawDescription:raw,editingVersion:cleanCard(body.card),confirmedVersion:null,confirmedAt:null,publishedAt:null,createdAt:now(),updatedAt:now(),revision:1};
  state.tasks.push(task);return task;
}
export function saveTask(state:Store,session:Session,taskId:string,body:any){const task=owned(state,session,taskId);revision(task,body.revision);const card=cleanCard(body.card);const rawDescription=z.string().trim().max(12000).parse(body.rawDescription??task.rawDescription);task.editingVersion=card;task.rawDescription=rawDescription;task.updatedAt=now();task.revision++;return task;}
export function confirmTask(state:Store,session:Session,taskId:string,body:any){const task=owned(state,session,taskId);revision(task,body.revision);check(meaningful(task.editingVersion.title),'Укажите название задачи.');check(meaningful(task.editingVersion.industry),'Выберите тему задачи.');task.confirmedVersion=structuredClone(task.editingVersion);task.confirmedAt=now();task.updatedAt=now();task.revision++;return task;}
export function publishTask(state:Store,session:Session,taskId:string,body:any){const task=owned(state,session,taskId);revision(task,body.revision);check(task.confirmedVersion && JSON.stringify(task.confirmedVersion)===JSON.stringify(task.editingVersion),'Сначала подтвердите текущие сведения.');task.publishedAt ||= now();task.updatedAt=now();task.revision++;return task;}
const nonempty=z.string().trim().min(3,'Заполните поле содержательным текстом.').max(6000);
const proposalSchema=z.object({taskId:z.string(),idea:nonempty,plan:nonempty,timeline:nonempty,prototypeUrl:z.string().url('Укажите полный адрес http:// или https://.').max(2000).refine(v=>/^https?:\/\//i.test(v),'Разрешены ссылки http и https.'),requestId:z.string().min(8).max(100)});
export function createProposal(state:Store,session:Session,body:any){
  team(session);const data=proposalSchema.parse(body);const old=state.proposals.find(p=>p.teamId===session.profileId && p.requestId===data.requestId);if(old)return old;
  const task=findTask(state,data.taskId);check(task.publishedAt&&task.confirmedVersion,'Можно откликаться на опубликованные задачи.');
  const proposal:Proposal={...data,id:id('proposal'),teamId:session.profileId,status:'submitted',createdAt:now(),decidedAt:null};state.proposals.push(proposal);return proposal;
}
export function decideProposal(state:Store,session:Session,proposalId:string,body:any){
  const proposal=state.proposals.find(p=>p.id===proposalId);check(proposal,'Предложение не найдено.',404);owned(state,session,proposal.taskId);
  proposal.status=z.enum(['selected','rejected','submitted']).parse(body.status);proposal.decidedAt=proposal.status==='submitted'?null:now();return proposal;
}
function selected(state:Store,taskId:string,teamId:string){return state.proposals.some(p=>p.taskId===taskId&&p.teamId===teamId&&p.status==='selected');}
export function createMilestone(state:Store,session:Session,body:any){
  team(session);const data=z.object({taskId:z.string(),title:nonempty,description:nonempty,evidence:nonempty,requestId:z.string().min(8).max(100)}).parse(body);
  const old=state.milestones.find(m=>m.teamId===session.profileId&&m.requestId===data.requestId);if(old)return old;
  findTask(state,data.taskId);check(selected(state,data.taskId,session.profileId),'Результат может представить выбранная команда.',403);
  const milestone:Milestone={...data,id:id('milestone'),teamId:session.profileId,status:'submitted',createdAt:now(),confirmedAt:null};state.milestones.push(milestone);return milestone;
}
export function confirmMilestone(state:Store,session:Session,milestoneId:string){
  const milestone=state.milestones.find(m=>m.id===milestoneId);check(milestone,'Этап не найден.',404);owned(state,session,milestone.taskId);
  if(milestone.status==='confirmed')return milestone;
  check(selected(state,milestone.taskId,milestone.teamId),'Команда должна быть выбрана для этой задачи.',409);
  milestone.status='confirmed';milestone.confirmedAt=now();
  if(!state.awards.some(a=>a.teamId===milestone.teamId&&a.milestoneId===milestone.id))state.awards.push({teamId:milestone.teamId,milestoneId:milestone.id,points:10});
  return milestone;
}
export function visibleStore(state:Store,session:Session):Store {
  const taskIds=new Set(state.tasks.filter(t=>t.businessId===session.profileId&&session.role==='business').map(t=>t.id));
  return {...state,tasks:state.tasks.filter(t=>taskIds.has(t.id)||t.publishedAt).map(t=>taskIds.has(t.id)?t:{...t,rawDescription:'',editingVersion:structuredClone(t.confirmedVersion!),confirmedVersion:structuredClone(t.confirmedVersion!)}),
    proposals:state.proposals.filter(p=>session.role==='team'?p.teamId===session.profileId:taskIds.has(p.taskId)),
    milestones:state.milestones.filter(m=>session.role==='team'?m.teamId===session.profileId:taskIds.has(m.taskId)),
    drafts:session.role==='business'?state.drafts:[]};
}
