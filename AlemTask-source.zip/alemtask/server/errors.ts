export class AppError extends Error {
  constructor(public status:number, message:string, public code='VALIDATION') { super(message); }
}
