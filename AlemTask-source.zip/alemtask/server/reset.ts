import {resetStore} from './store.js';
resetStore();console.log('Демонстрационные данные восстановлены. Предыдущие изменения удалены.');
