import { DatabaseSync } from 'node:sqlite';
import { mkdirSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import type {Store} from '../shared/types.js';
import {createSeed} from '../shared/seed.js';

const filename=resolve(process.env.DATA_PATH || '.data/alemtask.sqlite');
mkdirSync(dirname(filename),{recursive:true});
const db=new DatabaseSync(filename);
db.exec('PRAGMA journal_mode=WAL; CREATE TABLE IF NOT EXISTS app_state(id INTEGER PRIMARY KEY CHECK(id=1), data TEXT NOT NULL)');
if(!db.prepare('SELECT id FROM app_state WHERE id=1').get()) db.prepare('INSERT INTO app_state(id,data) VALUES(1,?)').run(JSON.stringify(createSeed()));
export function readStore():Store {
  return JSON.parse((db.prepare('SELECT data FROM app_state WHERE id=1').get() as {data:string}).data);
}
export function mutateStore<T>(fn:(state:Store)=>T):T {
  db.exec('BEGIN IMMEDIATE');
  try { const state=readStore(); const value=fn(state); db.prepare('UPDATE app_state SET data=? WHERE id=1').run(JSON.stringify(state)); db.exec('COMMIT');return value; }
  catch(error){db.exec('ROLLBACK');throw error;}
}
export function resetStore(){return mutateStore(state=>{Object.assign(state,createSeed());return state;});}
