import {createServer, type IncomingMessage, type ServerResponse} from 'node:http';
import {readFileSync,existsSync} from 'node:fs';
import {resolve,extname,sep} from 'node:path';
import {createServer as createViteServer} from 'vite';
import {ZodError} from 'zod';
import type {Session,Store} from '../shared/types.js';
import {readStore,mutateStore} from './store.js';
import {AppError} from './errors.js';
import {analyze,aiStatus} from './ai.js';
import * as actions from './actions.js';

const port=Number(process.env.PORT)||4317;
const production=process.argv.includes('--production');
const vite=production?null:await createViteServer({configLoader:'native',server:{middlewareMode:true,hmr:{port:4318}},appType:'spa'});
function json(res:ServerResponse,value:unknown,status=200){res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});res.end(JSON.stringify(value));}
async function body(req:IncomingMessage){let raw='';for await(const chunk of req){raw+=chunk;if(Buffer.byteLength(raw)>100_000)throw new AppError(413,'Слишком большой запрос.');}try{return JSON.parse(raw||'{}');}catch{throw new AppError(400,'Запрос имеет неверный формат JSON.');}}
function session(req:IncomingMessage,state:Store):Session {
  const role=req.headers['x-demo-role']||'business';const profileId=req.headers['x-demo-profile']||(role==='team'?'team-1':'business-1');
  if((role!=='business'&&role!=='team')||typeof profileId!=='string')throw new AppError(400,'Выберите демонстрационный профиль.');
  if(!(role==='business'?state.businesses:state.teams).some(p=>p.id===profileId))throw new AppError(400,'Демонстрационный профиль не найден.');
  return {role,profileId};
}
const busyAI=new Set<string>();
const server=createServer(async(req,res)=>{
  const url=new URL(req.url||'/',`http://127.0.0.1:${port}`);const path=url.pathname;const method=req.method||'GET';
  try{
    // Local demo only. Deny cross-origin writes and DNS-rebinding requests.
    const host=(req.headers.host||'').split(':')[0];
    if(!['127.0.0.1','localhost','[::1]'].includes(host))throw new AppError(403,'Разрешён только локальный доступ.');
    if(path.startsWith('/api/')){
      if(method!=='GET'&&req.headers.origin&&!['http://127.0.0.1:'+port,'http://localhost:'+port].includes(req.headers.origin))throw new AppError(403,'Запрос с другого сайта запрещён.');
      if(path==='/api/health'){json(res,{ok:true});return;}
      const state=readStore();const who=session(req,state);
      if(method==='GET'&&path==='/api/state'){json(res,{...actions.visibleStore(state,who),ai:aiStatus()});return;}
      if(method==='GET'&&path==='/api/ai/status'){json(res,aiStatus());return;}
      const input=method==='GET'?{}:await body(req);
      if(method==='POST'&&path==='/api/ai'){
        if(who.role!=='business')throw new AppError(403,'AI-конструктор доступен представителю бизнеса.');
        if(busyAI.has(who.profileId))throw new AppError(429,'Дождитесь завершения предыдущего AI-запроса.');
        busyAI.add(who.profileId);try{json(res,await analyze(input));}finally{busyAI.delete(who.profileId);}return;
      }
      if(method==='POST'&&path==='/api/tasks'){json(res,{task:mutateStore(s=>actions.createTask(s,who,input))},201);return;}
      const taskMatch=path.match(/^\/api\/tasks\/([^/]+)(?:\/(confirm|publish))?$/);
      if(taskMatch){const [,taskId,action]=taskMatch;
        if(method==='PUT'&&!action){json(res,{task:mutateStore(s=>actions.saveTask(s,who,taskId,input))});return;}
        if(method==='POST'&&action==='confirm'){json(res,{task:mutateStore(s=>actions.confirmTask(s,who,taskId,input))});return;}
        if(method==='POST'&&action==='publish'){json(res,{task:mutateStore(s=>actions.publishTask(s,who,taskId,input))});return;}
      }
      if(method==='POST'&&path==='/api/proposals'){json(res,{proposal:mutateStore(s=>actions.createProposal(s,who,input))},201);return;}
      const proposalMatch=path.match(/^\/api\/proposals\/([^/]+)$/);
      if(method==='PATCH'&&proposalMatch){json(res,{proposal:mutateStore(s=>actions.decideProposal(s,who,proposalMatch[1],input))});return;}
      if(method==='POST'&&path==='/api/milestones'){json(res,{milestone:mutateStore(s=>actions.createMilestone(s,who,input))},201);return;}
      const milestoneMatch=path.match(/^\/api\/milestones\/([^/]+)\/confirm$/);
      if(method==='POST'&&milestoneMatch){json(res,{milestone:mutateStore(s=>actions.confirmMilestone(s,who,milestoneMatch[1]))});return;}
      throw new AppError(404,'Этот адрес не найден.');
    }
    if(path==='/demo-prototype'){
      res.writeHead(200,{'Content-Type':'text/html; charset=utf-8'});res.end('<!doctype html><html lang="ru"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Пример прототипа — AlemTask</title><style>body{font:16px/1.6 system-ui;background:#f5f6f8;color:#182230;max-width:800px;margin:80px auto;padding:24px}a{color:#2f5d62}article{background:white;padding:32px;border:1px solid #d0d5dd;border-radius:16px}table{width:100%;text-align:left}td,th{padding:12px;border-bottom:1px solid #eee}</style><article><p>ДЕМОНСТРАЦИОННЫЙ ПРОТОТИП</p><h1>Заявки учебного центра</h1><p>Синтетические данные для демонстрации ссылки из предложения.</p><table><tr><th>Заявка</th><th>Курс</th><th>Статус</th></tr><tr><td>001</td><td>Python</td><td>Новая</td></tr><tr><td>002</td><td>Веб-разработка</td><td>В работе</td></tr></table><p><a href="/">Вернуться в AlemTask</a></p></article></html>');return;
    }
    if(vite){vite.middlewares(req,res);return;}
    const root=resolve('dist');const resolved=resolve(root,'.'+decodeURIComponent(path));
    const file=resolved.startsWith(root+sep)&&existsSync(resolved)&&extname(resolved)?resolved:resolve(root,'index.html');
    const mime:Record<string,string>={'.html':'text/html; charset=utf-8','.js':'application/javascript','.css':'text/css','.svg':'image/svg+xml','.png':'image/png','.woff2':'font/woff2'};
    res.writeHead(200,{'Content-Type':mime[extname(file)]||'application/octet-stream','X-Content-Type-Options':'nosniff'});res.end(readFileSync(file));
  }catch(error){
    if(error instanceof ZodError){json(res,{error:error.issues[0]?.message||'Проверьте заполнение полей.',code:'VALIDATION'},400);return;}
    if(error instanceof AppError){json(res,{error:error.message,code:error.code},error.status);return;}
    console.error('Request failed:',error instanceof Error?error.name:'UnknownError');json(res,{error:'Не удалось сохранить данные. Попробуйте ещё раз.',code:'INTERNAL'},500);
  }
});
server.listen(port,'127.0.0.1',()=>console.log(`AlemTask: http://127.0.0.1:${port} (${production?'production':'development'})`));
process.on('SIGINT',()=>{server.close();void vite?.close();process.exit(0);});
