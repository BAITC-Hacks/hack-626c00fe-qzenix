import OpenAI from 'openai';
import {zodTextFormat} from 'openai/helpers/zod';
import {z} from 'zod';
import {readFileSync} from 'node:fs';
import {resolve} from 'node:path';
import {createHash} from 'node:crypto';
import type {AIInput,AIResult,AIStatus,Card,CardField,AIQuestion} from '../shared/types.js';
import {emptyCard,meaningful,FIELD_LABELS} from '../shared/domain.js';
import {AppError} from './errors.js';

const keys=Object.keys(emptyCard()) as [CardField,...CardField[]];
const externalKeys=keys.filter(k=>k!=='contact') as [Exclude<CardField,'contact'>,...Exclude<CardField,'contact'>[]];
const questionSchema=z.object({id:z.string(),field:z.enum(keys),question:z.string(),reason:z.string()});
const extractionSchema=z.object({facts:z.array(z.object({field:z.enum(externalKeys),value:z.string(),quote:z.string()})),warnings:z.array(z.string())});
const questionsSchema=z.object({questions:z.array(questionSchema)});
const inputSchema=z.object({action:z.enum(['analyze','compose']),rawDescription:z.string().trim().min(3).max(12000),industry:z.string().max(200),currentCard:z.record(z.string().max(5000)).optional(),answers:z.array(z.object({id:z.string().max(200),field:z.enum(keys),question:z.string().max(2000).optional(),answer:z.string().max(5000)})).max(60),previousQuestions:z.array(questionSchema).max(60).optional(),lockedFields:z.array(z.enum(keys)).max(keys.length).optional(),mode:z.enum(['openai','local']).optional()});
const system=readFileSync(resolve('prompts/task-assistant.md'),'utf8');
const extractionSystem=readFileSync(resolve('prompts/task-extraction.md'),'utf8');
let lastSuccessAt:string|null=null;
let lastError:string|null=null;
export function aiStatus():AIStatus{return {configured:!!(process.env.OPENAI_API_KEY&&process.env.OPENAI_MODEL),model:process.env.OPENAI_MODEL||'',lastSuccessAt,lastError};}

const questions:Partial<Record<CardField,[string,string]>>={
  context:['Как сейчас устроен процесс и где возникает проблема?','Укажите текущий процесс'],
  need:['Что именно вы хотите изменить в работе бизнеса?','Опишите необходимое изменение'],
  users:['Кто будет пользоваться решением и в какой ситуации?','Нужна целевая группа'],
  data:['Какие данные, примеры или источники доступны команде?','Материалы помогают начать работу'],
  resultType:['В каком виде команда должна передать результат: прототип, отчёт или модуль?','Нужен вид результата'],
  expectedResult:['Что конкретно должен делать или содержать результат команды?','Нужно понятное описание результата'],
  successCriteria:['Как вы проверите результат: какое действие или метрику измерите?','Нужна проверка результата'],
  successTarget:['Какое целевое значение или проверяемое условие означает успех?','Нужно условие принятия'],
  constraints:['Какие сроки, технологии или ограничения доступа нужно учитывать?','Нужны границы задачи'],
  consultationFormat:['Как вы сможете консультировать команду?','Нужен формат консультаций'],
  feedbackProcess:['Как быстро и в каком порядке вы будете давать обратную связь?','Нужен порядок обратной связи']
};
function normalize(v:string){return v.toLowerCase().replace(/ё/g,'е').replace(/[^\p{L}\p{N}]+/gu,' ').trim();}
function baseCard(input:AIInput):Card {const card=emptyCard();for(const field of keys)card[field]=input.currentCard?.[field]||'';card.industry=input.industry;return card;}
function missing(card:Partial<Card>):CardField[]{return keys.filter(k=>!meaningful(card[k]||''));}
function summaryFor(card:Card,raw:string):string{
  const facts=[card.context,card.need,card.expectedResult].filter(meaningful);
  return (facts.length?[...new Set(facts)].join(' '):raw.trim()).slice(0,1200);
}
function sameQuestion(a:AIQuestion,b:AIQuestion):boolean{
  if(a.field!==b.field)return false;
  if(normalize(a.question)===normalize(b.question))return true;
  const stop=new Set(['какой','какие','какая','каких','какое','котор','нужно','нужен','будет','будут','именно','можно','вашей','вашего','пожал','задач','проект','чтобы','этого','этой']);
  const words=(s:string)=>new Set(normalize(s).split(' ').filter(w=>w.length>=3).map(w=>w.slice(0,5)).filter(w=>!stop.has(w)));
  const aw=words(a.question),bw=words(b.question);
  if(Math.min(aw.size,bw.size)<2)return false;
  const overlap=[...aw].filter(w=>bw.has(w)).length;
  return overlap/Math.max(aw.size,bw.size)>=0.65;
}
function chooseQuestions(candidates:AIQuestion[],input:AIInput,card:Card,warnings:string[]):AIQuestion[]{
  const answered=input.answers.filter(a=>a.answer.trim()).map(a=>({id:a.id,field:a.field,question:a.question||input.previousQuestions?.find(q=>q.id===a.id&&q.field===a.field)?.question||'',reason:''})).filter(q=>q.question);
  const result:AIQuestion[]=[];
  for(const q of candidates){
    if(['title','industry','contact'].includes(q.field)||!meaningful(q.question)||result.some(old=>sameQuestion(old,q))||answered.some(old=>sameQuestion(old,q)))continue;
    const conflict=warnings.some(w=>/противореч|конфликт|расходятся/i.test(w)&&normalize(w).includes(normalize(FIELD_LABELS[q.field])));
    if(meaningful(card[q.field])&&!conflict)continue;
    const id='q-'+createHash('sha256').update(q.field+'\n'+normalize(q.question)).digest('hex').slice(0,20);
    result.push({...q,id});
    if(result.length===6)break;
  }
  return result;
}
function requireComplete(response:{status?:string;output:any[]}){
  if(response.status==='incomplete')throw new AppError(502,'Ответ AI оказался незавершённым. Попробуйте ещё раз.','AI_INCOMPLETE');
  if(response.output.some(item=>item.type==='message'&&item.content?.some((c:{type:string})=>c.type==='refusal')))throw new AppError(422,'AI не смог обработать этот запрос. Уточните бизнес-задачу или используйте ручное заполнение.','AI_REFUSAL');
}
export function localAnalyze(input:AIInput):AIResult{
  const card=baseCard(input);
  // A local fallback can copy explicit detail, but cannot interpret a contextual yes/no answer.
  for(const answer of input.answers)if(!meaningful(card[answer.field])&&meaningful(answer.answer)&&!(/^(да|нет|yes|no|ия|иә|жоқ)[.!\s]*$/i.test(answer.answer)))card[answer.field]=answer.answer.trim();
  const gapKeys=missing(card).filter(k=>questions[k]);
  const qs:AIQuestion[]=gapKeys.slice(0,6).map((field,i)=>({id:'local-'+i,field,question:questions[field]![0],reason:questions[field]![1]}));
  return {mode:'local',summary:summaryFor(card,input.rawDescription),questions:chooseQuestions(qs,input,card,[]),cardDraft:card,missingFields:missing(card),warnings:['Используется локальная логика по правилам. Это резервный режим, без ответа языковой модели.']};
}

export function errorForAI(error:unknown):AppError {
  if(error instanceof AppError)return error;
  const e=(typeof error==='object'&&error!==null?error:{}) as {status?:number;name?:string;code?:string};
  if(e.status===401)return new AppError(502,'OpenAI не принял ключ. Проверьте серверную настройку ключа.','AI_AUTH');
  if(e.status===403)return new AppError(502,'У этого проекта нет доступа к выбранной модели.','AI_PERMISSION');
  if(e.status===404)return new AppError(502,'Выбранная модель недоступна. Проверьте OPENAI_MODEL.','AI_MODEL');
  if(e.status===429)return new AppError(503,'OpenAI временно ограничил запросы или исчерпан лимит проекта. Попробуйте позже либо продолжите в демо-режиме.','AI_LIMIT');
  if(e.name?.includes('Timeout')||e.name==='AbortError')return new AppError(504,'AI не успел ответить. Введённые данные сохранены в форме. Повторите запрос или выберите демо-режим.','AI_TIMEOUT');
  if(error instanceof z.ZodError||error instanceof SyntaxError)return new AppError(502,'AI вернул некорректный ответ. Данные не изменены. Попробуйте ещё раз.','AI_FORMAT');
  return new AppError(502,'Не удалось получить ответ OpenAI. Проверьте соединение или продолжите в демо-режиме.','AI_UNAVAILABLE');
}

export async function analyze(inputRaw:unknown):Promise<AIResult>{
  const input=inputSchema.parse(inputRaw) as AIInput;
  if(input.mode==='local')return localAnalyze(input);
  if(!aiStatus().configured)throw new AppError(503,'AI ещё не настроен. Нужны серверные OPENAI_API_KEY и OPENAI_MODEL. Можно продолжить в демо-режиме.','AI_CONFIG');
  const client=new OpenAI({apiKey:process.env.OPENAI_API_KEY,timeout:Number(process.env.AI_TIMEOUT_MS)||45000,maxRetries:1});
  const initial=baseCard(input);
  const locked=new Set<CardField>(input.lockedFields??keys.filter(k=>meaningful(initial[k])));
  if(meaningful(input.industry))locked.add('industry');
  // Redact every outward text field before JSON serialization. The local card stays intact.
  const redact=(s:string)=>{
    const contacts=[initial.contact,...input.answers.filter(a=>a.field==='contact').map(a=>a.answer)].filter(Boolean);
    const withoutKnownContact=contacts.reduce((text,contact)=>text.split(contact).join('[контакт скрыт]'),s);
    return withoutKnownContact.replace(/\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b/gi,'[контакт скрыт]');
  };
  const withoutContact=Object.fromEntries(externalKeys.map(k=>[k,initial[k]?redact(initial[k]):null]));
  const answers=input.answers.filter(a=>a.field!=='contact').map(a=>({...a,question:redact(a.question||input.previousQuestions?.find(q=>q.id===a.id&&q.field===a.field)?.question||''),answer:redact(a.answer)}));
  const previousQuestions=(input.previousQuestions||[]).filter(q=>q.field!=='contact').map(q=>({...q,question:redact(q.question),reason:redact(q.reason)}));
  const payload={action:input.action,rawDescription:redact(input.rawDescription),industry:redact(input.industry),currentCard:withoutContact,answers,previousQuestions,lockedFields:[...locked].filter(k=>k!=='contact'),phase:previousQuestions.length||answers.some(a=>a.answer.trim())?'follow_up':'initial'};
  const serialized=JSON.stringify(payload);
  // A model question is not a fact. Only explicit yes/no confirmation can ground its wording.
  const confirmedAnswers=answers.filter(a=>a.question&&/^(да|нет|yes|no|ия|иә|жоқ)[.!\s]*$/i.test(a.answer.trim())).map(a=>`Вопрос: ${a.question} Ответ: ${a.answer}`);
  const corpus=normalize([payload.rawDescription,payload.industry,...Object.values(withoutContact).filter(Boolean),...payload.answers.map(a=>a.answer),...confirmedAnswers].join('\n'));
  try{
    const extraction=await client.responses.parse({model:process.env.OPENAI_MODEL!,store:false,input:[{role:'system',content:extractionSystem},{role:'user',content:serialized}],text:{format:zodTextFormat(extractionSchema,'task_facts')},max_output_tokens:4500});
    requireComplete(extraction);
    const parsed=extractionSchema.parse(extraction.output_parsed);
    const card={...initial};const warnings=[...parsed.warnings];
    for(const field of externalKeys){
      if(locked.has(field))continue;
      const suggested=parsed.facts.filter(f=>f.field===field&&meaningful(f.value));
      const grounded=suggested.filter(f=>f.quote.trim().length>=3&&corpus.includes(normalize(f.quote)));
      if(grounded.length)card[field]=[...new Set(grounded.map(f=>f.value.trim()))].join(' ');
      if(!meaningful(initial[field])&&grounded.length<suggested.length)warnings.push(`Предложение для поля «${FIELD_LABELS[field]}» не применено: нет проверяемой цитаты из ваших сведений.`);
    }
    const actionableMissing=missing(card).filter(k=>questions[k]);
    let contextual:AIQuestion[]=[];
    let requestId=extraction.id;
    if(input.action==='analyze'&&(actionableMissing.length||warnings.length)){
      const knownCard=Object.fromEntries(externalKeys.map(k=>[k,card[k]?redact(card[k]):null]));
      const questionPayload={...payload,currentCard:knownCard,missingFields:actionableMissing,warnings};
      const response=await client.responses.parse({model:process.env.OPENAI_MODEL!,store:false,input:[{role:'system',content:system},{role:'user',content:JSON.stringify(questionPayload)}],text:{format:zodTextFormat(questionsSchema,'task_questions')},max_output_tokens:2500});
      requireComplete(response);
      const next=questionsSchema.parse(response.output_parsed);
      const unique=next.questions.filter((q,i,arr)=>meaningful(q.question)&&arr.findIndex(v=>sameQuestion(v,q))===i);
      if(payload.phase==='initial'&&actionableMissing.length>=3&&unique.length<3)throw new AppError(502,'AI вернул слишком мало вопросов по неясным деталям. Повторите запрос.','AI_FORMAT');
      contextual=chooseQuestions(unique,input,card,warnings);
      requestId=response.id;
    }
    lastSuccessAt=new Date().toISOString();lastError=null;
    return {mode:'openai',model:extraction.model,summary:summaryFor(card,input.rawDescription),questions:contextual,cardDraft:card,missingFields:missing(card),warnings,requestId};
  }catch(error){const safe=errorForAI(error);lastError=safe.message;throw safe;}
}
