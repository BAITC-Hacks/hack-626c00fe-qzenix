import type { AIQuestion, Card, CardField } from './types.js';

export type AIContext = { raw: string; industry: string };
export type SessionAnswer = { id: string; field: CardField; question: string; answer: string };
export type AIArchive = {
  savedAt: string; reason: string; raw: string; card: Card;
  questions: AIQuestion[]; answers: SessionAnswer[];
};
export type BuilderAISession = {
  version: 2; context: AIContext | null; manualFields: CardField[]; derivedFields: CardField[];
  previousQuestions: AIQuestion[]; historyAnswers: SessionAnswer[]; summary: string;
  archives: AIArchive[]; needsRefresh?: boolean;
};

export const questionIdentity = (question: Pick<AIQuestion, 'field' | 'question'>) =>
  question.field + ':' + question.question.trim().replace(/\s+/g, ' ').toLocaleLowerCase();

export function sameAIContext(context: AIContext | null, raw: string, industry: string) {
  return !!context && context.raw.trim() === raw.trim() && context.industry.trim() === industry.trim();
}

export function freshAISession(manualFields: CardField[] = []): BuilderAISession {
  return { version: 2, context: null, manualFields, derivedFields: [], previousQuestions: [], historyAnswers: [], summary: '', archives: [] };
}

// A model-generated id or a shared destination field is not evidence that two questions mean the same thing.
export function answersForQuestions(previous: AIQuestion[], answers: Record<string, string>, next: AIQuestion[]) {
  const byQuestion = new Map(previous.map(question => [questionIdentity(question), answers[question.id] || '']));
  return Object.fromEntries(next.map(question => [question.id, byQuestion.get(questionIdentity(question)) || '']));
}

export function conversationHistory(session: Pick<BuilderAISession, 'previousQuestions' | 'historyAnswers'>, questions: AIQuestion[], answers: Record<string, string>) {
  const questionMap = new Map(session.previousQuestions.map(question => [questionIdentity(question), question]));
  const answerMap = new Map(session.historyAnswers.map(answer => [questionIdentity(answer), answer]));
  for (const question of questions) {
    questionMap.set(questionIdentity(question), question);
    answerMap.set(questionIdentity(question), { id: question.id, field: question.field, question: question.question, answer: answers[question.id] || '' });
  }
  return { previousQuestions: [...questionMap.values()], historyAnswers: [...answerMap.values()] };
}

export function requestCard(card: Card, session: Pick<BuilderAISession, 'manualFields' | 'derivedFields'>, contextChanged: boolean): Card {
  const next = { ...card };
  if (contextChanged) for (const field of session.derivedFields) if (!session.manualFields.includes(field)) next[field] = '';
  return next;
}

export function mergeAIDraft(current: Card, requested: Card, draft: Partial<Card>, manualFields: CardField[]) {
  const card = { ...current };
  const derivedFields: CardField[] = [];
  for (const field of Object.keys(current) as CardField[]) {
    const proposed = draft[field];
    if (manualFields.includes(field) || current[field] !== requested[field] || typeof proposed !== 'string' || !proposed.trim()) continue;
    card[field] = proposed;
    derivedFields.push(field);
  }
  return { card, derivedFields };
}

export function archiveAIContext(session: BuilderAISession, raw: string, card: Card, questions: AIQuestion[], answers: Record<string, string>, reason: string): AIArchive {
  const history = conversationHistory(session, questions, answers);
  return { savedAt: new Date().toISOString(), reason, raw, card: { ...card }, questions: history.previousQuestions, answers: history.historyAnswers };
}

export function migrateLegacyAI(raw: string, card: Card, questions: AIQuestion[], answers: Record<string, string>, confirmedCard?: Card | null): BuilderAISession {
  const populated = (Object.keys(card) as CardField[]).filter(field => card[field].trim());
  const manualFields = populated.filter(field => field === 'contact' || field === 'industry' || confirmedCard?.[field] === card[field]);
  const session = freshAISession(manualFields);
  session.context = { raw, industry: card.industry };
  session.derivedFields = populated.filter(field => !manualFields.includes(field));
  session.needsRefresh = true;
  session.archives = [archiveAIContext(session, raw, card, questions, answers, 'Сведения до обновления помощника')];
  return session;
}
