import type { Card, CardField, Task } from './types.js';

export const FIELD_LABELS: Record<CardField, string> = {
  title: 'Название', industry: 'Тема / отрасль', context: 'Контекст', need: 'Потребность',
  users: 'Пользователи', data: 'Данные и материалы', constraints: 'Ограничения',
  expectedResult: 'Описание результата', resultType: 'Тип результата',
  successCriteria: 'Проверка / метрика', successTarget: 'Целевое условие',
  contact: 'Контакт бизнеса', consultationFormat: 'Формат консультаций',
  feedbackProcess: 'Порядок обратной связи',
};

export const INDUSTRIES = ['Образование', 'Услуги', 'Розница', 'Сельское хозяйство', 'Логистика'];

export function emptyCard(): Card {
  return Object.fromEntries(Object.keys(FIELD_LABELS).map(key => [key, ''])) as Card;
}

/** Checks presence, not business truth. A person must still confirm the actual facts. */
export function meaningful(value: string): boolean {
  if (typeof value !== 'string') return false;
  const text = value.normalize('NFKC').trim().toLocaleLowerCase('ru-RU')
    .replace(/\s+/gu, ' ').replace(/^[\p{P}\p{S}\s]+|[\p{P}\p{S}\s]+$/gu, '');
  if (!/[\p{L}\p{N}]/u.test(text)) return false;
  const placeholders = new Set([
    'не знаю', 'неизвестно', 'не известно', 'не указано', 'не указан', 'не указаны',
    'не определено', 'не определён', 'не определен', 'уточняется', 'уточним',
    'потом', 'позже', 'пока нет', 'нет данных', 'нет информации', 'отсутствует',
    'отсутствуют', 'нет', 'да', 'заполнить', 'тест', 'test', 'todo', 'tbd',
    'unknown', 'not specified', 'none', 'null', 'undefined', 'n/a', 'na',
    'білмеймін', 'белгісіз', 'көрсетілмеген', 'кейін', 'жоқ',
  ]);
  return !placeholders.has(text);
}

export function readiness(score: number): string {
  const normalized = Number.isFinite(score) ? Math.max(0, Math.min(100, score)) : 0;
  if (normalized < 40) return 'Черновик';
  if (normalized < 70) return 'Рабочая';
  if (normalized < 90) return 'Готовая';
  return 'Приоритетная';
}

type Condition = { fields: CardField[]; points: number };
type CategoryDefinition = { key: string; label: string; max: number; conditions: Condition[] };
const CATEGORIES: CategoryDefinition[] = [
  { key: 'contextNeed', label: 'Контекст и потребность', max: 20, conditions: [
    { fields: ['context'], points: 10 }, { fields: ['need'], points: 10 },
  ] },
  { key: 'data', label: 'Данные и материалы', max: 20, conditions: [{ fields: ['data'], points: 20 }] },
  { key: 'result', label: 'Ожидаемый результат', max: 15, conditions: [
    { fields: ['resultType', 'expectedResult'], points: 15 },
  ] },
  { key: 'success', label: 'Критерии успеха', max: 15, conditions: [
    { fields: ['successCriteria', 'successTarget'], points: 15 },
  ] },
  { key: 'constraints', label: 'Ограничения', max: 10, conditions: [{ fields: ['constraints'], points: 10 }] },
  { key: 'users', label: 'Пользователи', max: 10, conditions: [{ fields: ['users'], points: 10 }] },
  { key: 'communication', label: 'Связь с бизнесом', max: 10, conditions: [
    { fields: ['contact'], points: 4 }, { fields: ['consultationFormat'], points: 3 },
    { fields: ['feedbackProcess'], points: 3 },
  ] },
];

export type ScoreResult = {
  total: number;
  level: string;
  categories: { key: string; label: string; score: number; max: number; fields: CardField[]; reason: string }[];
  missing: { field: CardField; label: string; points: number }[];
};

/** This pure function is also used for previews. Pass confirmedVersion for an official score. */
export function scoreCard(card: Partial<Card> | null): ScoreResult {
  const missing: ScoreResult['missing'] = [];
  const categories = CATEGORIES.map(category => {
    let score = 0;
    const missingFields: CardField[] = [];
    for (const condition of category.conditions) {
      const absent = condition.fields.filter(field => !meaningful(card?.[field] ?? ''));
      if (!absent.length) {
        score += condition.points;
      } else {
        missingFields.push(...absent);
        // Paired conditions earn once: never promise +30 for one 15-point category.
        missing.push({ field: absent[0], label: absent.map(field => FIELD_LABELS[field]).join(' и '), points: condition.points });
      }
    }
    return {
      key: category.key, label: category.label, score, max: category.max,
      fields: category.conditions.flatMap(condition => condition.fields),
      reason: missingFields.length
        ? `Добавьте: ${missingFields.map(field => FIELD_LABELS[field]).join(', ')}.`
        : 'Все сведения этой категории заполнены.',
    };
  });
  const total = categories.reduce((sum, category) => sum + category.score, 0);
  missing.sort((a, b) => b.points - a.points);
  return { total, level: readiness(total), categories, missing };
}

/** Rating DESC, publication date ASC, ID ASC. Editing never changes the public order. */
export function sortedPublished(tasks: Task[]): Task[] {
  return tasks.filter(task => Boolean(task.publishedAt && task.confirmedAt && task.confirmedVersion))
    .sort((a, b) => scoreCard(b.confirmedVersion).total - scoreCard(a.confirmedVersion).total
      || a.publishedAt!.localeCompare(b.publishedAt!) || a.id.localeCompare(b.id));
}
