import { emptyCard } from './domain.js';
import type { Card, Proposal, Store, Task } from './types.js';

export const DEMO_CARD: Card = {
  title: 'Единый список заявок учебного центра', industry: 'Образование',
  context: 'Заявки приходят в мессенджер; администратор вручную переносит их в таблицу.',
  need: 'Нужен единый список заявок и статусов обработки.',
  users: 'Администратор учебного центра, который обрабатывает новые заявки.',
  data: 'Доступен синтетический CSV из 100 заявок с датой, курсом и статусом.',
  constraints: 'Срок — 2 недели; только синтетические данные, без подключения к рабочей CRM.',
  resultType: 'Веб-прототип', expectedResult: 'Список заявок с поиском и изменением статуса.',
  successCriteria: 'Найти каждую из 10 заранее подготовленных заявок.',
  successTarget: 'Каждая заявка найдена администратором не дольше чем за 30 секунд.',
  contact: 'contact@example.com', consultationFormat: 'Две онлайн-консультации по 15 минут в неделю.',
  feedbackProcess: 'Ответы на вопросы в течение одного рабочего дня.',
};

function task(id: string, card: Card, rawDescription: string, day: number): Task {
  const date = `2026-09-${String(day).padStart(2, '0')}T09:00:00.000Z`;
  return { id, businessId: 'business-1', rawDescription, editingVersion: { ...card },
    confirmedVersion: { ...card }, confirmedAt: date, publishedAt: date, createdAt: date,
    updatedAt: date, revision: 1 };
}

/** A fresh, deterministic synthetic store. No references are shared across calls or versions. */
export function createSeed(): Store {
  const low: Card = { ...emptyCard(), title: 'Очередь заявок учебного центра', industry: 'Образование',
    context: DEMO_CARD.context, need: DEMO_CARD.need };
  const working: Card = { ...emptyCard(), title: 'Запись клиентов в мастерскую', industry: 'Услуги',
    context: 'Заявки на ремонт поступают по телефону и записываются в общий блокнот.',
    need: 'Собрать записи и статусы ремонта в одном интерфейсе.', users: 'Диспетчер небольшой мастерской.',
    data: 'Синтетическая таблица из 60 обращений: дата, тип ремонта, статус.',
    resultType: 'Веб-прототип', expectedResult: 'Форма записи и список обращений с фильтром по статусу.' };
  const ready: Card = { ...DEMO_CARD, title: 'Контроль остатков небольшого магазина', industry: 'Розница',
    context: 'Сотрудники вручную сверяют остатки в разных таблицах.',
    need: 'Показывать товары, которые требуется заказать.', users: 'Управляющий и кладовщик магазина.', data: '',
    constraints: 'Прототип за 2 недели; без подключения к кассе.',
    expectedResult: 'Экран остатков и список товаров ниже минимального порога.',
    successCriteria: 'Проверка уведомлений на 10 синтетических товарах.',
    successTarget: 'Все товары ниже порога отображаются без ложных срабатываний.',
    contact: 'retail@example.com' };
  const priority: Card = { ...DEMO_CARD, title: 'Планирование полива теплицы', industry: 'Сельское хозяйство',
    context: 'Агроном переносит показатели влажности из журнала в таблицу.',
    need: 'Сопоставить влажность и график полива на одном экране.', users: 'Агроном учебной теплицы.',
    data: 'Доступна синтетическая CSV-выгрузка влажности 8 участков за 14 дней.',
    constraints: 'Работать только с синтетическими измерениями; не управлять оборудованием.',
    expectedResult: 'Графики влажности и редактируемый план полива.',
    successCriteria: 'Сопоставить графики с 8 контрольными рядами измерений.',
    successTarget: 'Все 8 рядов отображаются без потерь и смещения дат.',
    contact: 'greenhouse@example.com', consultationFormat: '', feedbackProcess: '' };
  const full: Card = { ...DEMO_CARD, title: 'Статусы доставки для диспетчера', industry: 'Логистика',
    context: 'Диспетчер обновляет статусы доставок в нескольких таблицах.',
    need: 'Объединить контроль статусов и поиск отправлений.', users: 'Диспетчер учебной службы доставки.',
    data: 'Доступна синтетическая CSV-таблица из 80 отправлений без персональных данных.',
    constraints: 'Срок — 2 недели; без геолокации реальных людей и внешних интеграций.',
    expectedResult: 'Список отправлений с фильтрами и ручной сменой статуса.',
    successCriteria: 'Найти каждое из 10 контрольных отправлений по коду.',
    successTarget: 'Каждое отправление найдено не дольше чем за 20 секунд.',
    contact: 'delivery@example.com' };
  const tasks = [
    task('task-1', low, 'Хотим автоматизировать заявки в учебном центре.', 18),
    task('task-2', working, 'Нужен удобный список записей на ремонт. Есть таблица обращений.', 19),
    task('task-3', ready, 'Нужен контроль остатков и перечень товаров к заказу. Данные пока не подготовлены.', 20),
    task('task-4', priority, 'Есть синтетические измерения влажности. Нужен экран для агронома.', 21),
    task('task-5', full, 'Нужен прототип списка доставок. Есть синтетическая CSV и критерии приёмки.', 22),
  ];
  const proposalData = [
    { teamId: 'team-1', taskId: 'task-3', idea: 'Таблица остатков с выделением товаров ниже порога.', plan: 'Уточнить формат → собрать прототип → проверить на синтетических товарах.', timeline: '10 рабочих дней' },
    { teamId: 'team-2', taskId: 'task-3', idea: 'Панель управляющего с фильтрами и списком закупок.', plan: 'Согласовать поля → построить панель → провести проверку с бизнесом.', timeline: '2 недели' },
    { teamId: 'team-3', taskId: 'task-1', idea: 'Единый журнал заявок и статусов для администратора.', plan: 'Уточнить доступные данные → согласовать результат → подготовить интерфейс.', timeline: '2 недели после уточнения данных' },
    { teamId: 'team-4', taskId: 'task-4', idea: 'Графики влажности и план полива для учебной теплицы.', plan: 'Изучить CSV → визуализировать ряды → сверить 8 контрольных участков.', timeline: '12 дней' },
    { teamId: 'team-5', taskId: 'task-5', idea: 'Поиск отправлений с понятной историей статусов.', plan: 'Подготовить модель → собрать список → проверить 10 отправлений.', timeline: '2 недели' },
  ];
  const proposals: Proposal[] = proposalData.map((item, index) => ({ ...item,
    id: `proposal-${index + 1}`, prototypeUrl: 'http://localhost:4317/demo-prototype', status: 'submitted',
    createdAt: `2026-09-23T0${index + 1}:00:00.000Z`, decidedAt: null, requestId: `seed-proposal-${index + 1}`,
  }));
  return {
    businesses: [{ id: 'business-1', name: 'Alem Demo · синтетический бизнес', demoContact: 'business@example.com' }],
    tasks,
    teams: [
      { id: 'team-1', name: 'Orbit · демокоманда', interests: ['Розница', 'Логистика'], skills: ['Интерфейсы', 'Веб-разработка'], technologies: ['React', 'TypeScript'] },
      { id: 'team-2', name: 'Data Qadam · демокоманда', interests: ['Розница', 'Образование'], skills: ['Анализ данных', 'Визуализация'], technologies: ['Python', 'SQL'] },
      { id: 'team-3', name: 'Jas Code · демокоманда', interests: ['Образование', 'Услуги'], skills: ['Прототипирование', 'Дизайн интерфейсов'], technologies: ['React', 'Figma'] },
      { id: 'team-4', name: 'Green Lab · демокоманда', interests: ['Сельское хозяйство'], skills: ['Обработка данных', 'Графики'], technologies: ['Python', 'JavaScript'] },
      { id: 'team-5', name: 'Route Team · демокоманда', interests: ['Логистика', 'Услуги'], skills: ['Backend', 'Веб-разработка'], technologies: ['Node.js', 'TypeScript'] },
    ],
    proposals, milestones: [], awards: [],
    drafts: tasks.map((item, index) => ({ id: `draft-${index + 1}`, rawDescription: item.rawDescription, industry: item.editingVersion.industry })),
  };
}
