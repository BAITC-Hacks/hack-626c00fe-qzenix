@echo off
setlocal
cd /d "%~dp0"
set "ALEM_NODE=node"
where node >nul 2>nul
if errorlevel 1 set "ALEM_NODE=%USERPROFILE%\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe"
if not exist "node_modules\typescript\bin\tsc" (
  echo Install dependencies first: pnpm install
  pause
  exit /b 1
)
if not exist "dist\index.html" (
  "%ALEM_NODE%" scripts\build.mjs
  if errorlevel 1 exit /b 1
)
echo Open http://127.0.0.1:4317 in your browser.
"%ALEM_NODE%" --env-file-if-exists=.env scripts\run.mjs --production
pause
