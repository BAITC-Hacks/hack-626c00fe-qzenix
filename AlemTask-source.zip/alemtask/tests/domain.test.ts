import test from 'node:test';
import assert from 'node:assert/strict';
import { emptyCard, FIELD_LABELS, meaningful, readiness, scoreCard, sortedPublished } from '../shared/domain.js';
import { createSeed, DEMO_CARD } from '../shared/seed.js';

test('all categories total 100; placeholders cannot earn points', () => {
  const complete = scoreCard(DEMO_CARD);
  assert.equal(complete.total, 100);
  assert.equal(complete.categories.reduce((sum, item) => sum + item.max, 0), 100);
  assert.equal(complete.missing.length, 0);
  assert.equal(scoreCard(null).total, 0);
  assert.equal(scoreCard(emptyCard()).total, 0);
  for (const value of [' ', ' — ', ' Не знаю! ', 'не указано', 'потом', 'N/A', 'белгісіз']) {
    assert.equal(meaningful(value), false, value);
  }
  assert.equal(meaningful('Срок — 2 недели'), true);
  assert.equal(meaningful('Не более 30 секунд на поиск'), true);
  assert.equal(meaningful('Қазақ тіліндегі өтінімдер'), true);
});

test('paired result/success inputs earn once and missing gains never double count', () => {
  assert.equal(scoreCard({ resultType: 'Веб-прототип' }).total, 0);
  assert.equal(scoreCard({ expectedResult: 'Список заявок' }).total, 0);
  assert.equal(scoreCard({ resultType: 'Веб-прототип', expectedResult: 'Список заявок' }).total, 15);
  assert.equal(scoreCard({ successCriteria: 'Поиск заявки' }).total, 0);
  assert.equal(scoreCard({ successCriteria: 'Поиск заявки', successTarget: 'До 30 секунд' }).total, 15);
  for (const card of [null, {}, { resultType: 'Веб-прототип' }, DEMO_CARD]) {
    const result = scoreCard(card);
    assert.equal(result.total + result.missing.reduce((sum, item) => sum + item.points, 0), 100);
  }
  const communication = scoreCard({ contact: 'demo@example.com' });
  assert.equal(communication.total, 4);
  assert.equal(communication.categories.find(item => item.key === 'communication')?.max, 10);
});

test('readiness includes the exact boundaries and normalizes invalid input', () => {
  const inputs = [0, 39, 40, 69, 70, 89, 90, 100];
  const labels = ['Черновик', 'Черновик', 'Рабочая', 'Рабочая', 'Готовая', 'Готовая', 'Приоритетная', 'Приоритетная'];
  assert.deepEqual(inputs.map(readiness), labels);
  assert.equal(readiness(-1), 'Черновик');
  assert.equal(readiness(101), 'Приоритетная');
  assert.equal(readiness(Number.NaN), 'Черновик');
});

test('demo grows 20 → 65 → 90 → 100 and confirmed deletion reduces the score', () => {
  const card = { ...emptyCard(), title: DEMO_CARD.title, industry: DEMO_CARD.industry,
    context: DEMO_CARD.context, need: DEMO_CARD.need };
  assert.equal(scoreCard(card).total, 20);
  Object.assign(card, { users: DEMO_CARD.users, data: DEMO_CARD.data,
    resultType: DEMO_CARD.resultType, expectedResult: DEMO_CARD.expectedResult });
  assert.equal(scoreCard(card).total, 65);
  Object.assign(card, { successCriteria: DEMO_CARD.successCriteria, successTarget: DEMO_CARD.successTarget,
    constraints: DEMO_CARD.constraints });
  assert.equal(scoreCard(card).total, 90);
  Object.assign(card, { contact: DEMO_CARD.contact, consultationFormat: DEMO_CARD.consultationFormat,
    feedbackProcess: DEMO_CARD.feedbackProcess });
  assert.equal(scoreCard(card).total, 100);
  card.data = '';
  assert.equal(scoreCard(card).total, 80);
});

test('catalog uses confirmed snapshots, includes low ratings, and does not mutate input', () => {
  const store = createSeed();
  const order = store.tasks.map(task => task.id);
  const low = store.tasks[0];
  low.editingVersion = { ...DEMO_CARD };
  assert.equal(scoreCard(low.editingVersion).total, 100);
  assert.equal(scoreCard(low.confirmedVersion).total, 20);
  assert.deepEqual(sortedPublished(store.tasks).map(task => task.id), ['task-5', 'task-4', 'task-3', 'task-2', 'task-1']);
  assert.deepEqual(store.tasks.map(task => task.id), order);
  low.confirmedVersion = { ...low.editingVersion };
  assert.equal(sortedPublished(store.tasks)[0].id, 'task-1');
  low.publishedAt = null;
  assert.equal(sortedPublished(store.tasks).some(task => task.id === low.id), false);
  const unconfirmed = { ...store.tasks[1], id: 'unconfirmed', confirmedVersion: null };
  assert.equal(sortedPublished([unconfirmed]).length, 0);
});

test('equal ratings sort by earlier publication then ID', () => {
  const template = createSeed().tasks[0];
  const a = { ...template, id: 'b', publishedAt: '2026-09-19T00:00:00.000Z' };
  const b = { ...template, id: 'c', publishedAt: '2026-09-18T00:00:00.000Z' };
  const c = { ...template, id: 'a', publishedAt: '2026-09-18T00:00:00.000Z' };
  assert.deepEqual(sortedPublished([a, b, c]).map(task => task.id), ['a', 'c', 'b']);
});

test('synthetic seed contains all required datasets, exact scores and valid links', () => {
  const store = createSeed();
  assert.ok(store.tasks.length >= 5 && store.drafts.length >= 5 && store.teams.length >= 5 && store.proposals.length >= 5);
  assert.deepEqual(store.tasks.map(task => scoreCard(task.confirmedVersion).total), [20, 65, 80, 94, 100]);
  for (const task of store.tasks) {
    assert.deepEqual(Object.keys(task.editingVersion).sort(), Object.keys(FIELD_LABELS).sort());
    assert.ok(store.businesses.some(business => business.id === task.businessId));
    assert.notEqual(task.editingVersion, task.confirmedVersion);
  }
  for (const proposal of store.proposals) {
    assert.ok(store.tasks.some(task => task.id === proposal.taskId));
    assert.ok(store.teams.some(team => team.id === proposal.teamId));
    assert.equal(new URL(proposal.prototypeUrl).protocol, 'http:');
  }
  assert.ok(store.proposals.filter(proposal => proposal.taskId === 'task-3').length >= 2);
  store.tasks[0].editingVersion.context = 'Изменённый текст';
  store.teams[0].skills.push('Новое значение');
  const fresh = createSeed();
  assert.equal(fresh.tasks[0].confirmedVersion?.context, DEMO_CARD.context);
  assert.equal(fresh.teams[0].skills.includes('Новое значение'), false);
});
