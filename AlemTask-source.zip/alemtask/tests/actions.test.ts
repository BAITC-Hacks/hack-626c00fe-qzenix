import test from 'node:test';
import assert from 'node:assert/strict';
import {
  cleanCard, confirmMilestone, confirmTask, createMilestone, createProposal, createTask,
  decideProposal, publishTask, saveTask, visibleStore,
} from '../server/actions.js';
import { emptyCard, scoreCard, sortedPublished } from '../shared/domain.js';
import { createSeed, DEMO_CARD } from '../shared/seed.js';
import type { Card, Session, Store } from '../shared/types.js';

const business: Session = { role: 'business', profileId: 'business-1' };
const team = (number = 1): Session => ({ role: 'team', profileId: `team-${number}` });
const errorStatus = (status: number) => (error: unknown) =>
  typeof error === 'object' && error !== null && 'status' in error && error.status === status;
const lowCard = (): Card => ({ ...emptyCard(), title: 'Новая задача учебного центра', industry: 'Образование',
  context: DEMO_CARD.context, need: DEMO_CARD.need });
function draft(state: Store, card = lowCard()) {
  return createTask(state, business, { rawDescription: 'Хотим автоматизировать обработку заявок.', card });
}
const proposalBody = (requestId: string, taskId = 'task-1') => ({ taskId, requestId,
  idea: 'Единый список заявок и статусов.', plan: 'Уточнить поля, собрать интерфейс, проверить примеры.',
  timeline: 'Две недели', prototypeUrl: 'http://localhost:4317/demo-prototype' });
const milestoneBody = (requestId: string, taskId = 'task-1') => ({ taskId, requestId,
  title: 'Первый работающий прототип', description: 'Подготовлен список синтетических заявок с фильтром.',
  evidence: 'Демонстрация на 10 синтетических заявках, результаты проверки приложены текстом.' });

test('creation and saving keep a private draft without official points or publication', () => {
  const state = createSeed();
  const task = draft(state);
  assert.equal(task.confirmedVersion, null);
  assert.equal(task.confirmedAt, null);
  assert.equal(task.publishedAt, null);
  assert.equal(scoreCard(task.editingVersion).total, 20);
  assert.equal(scoreCard(task.confirmedVersion).total, 0);
  assert.equal(visibleStore(state, team()).tasks.some(item => item.id === task.id), false);
  assert.equal(visibleStore(state, business).tasks.some(item => item.id === task.id), true);
  saveTask(state, business, task.id, { revision: 1, card: DEMO_CARD });
  assert.equal(task.revision, 2);
  assert.equal(scoreCard(task.editingVersion).total, 100);
  assert.equal(task.confirmedVersion, null);
  assert.throws(() => publishTask(state, business, task.id, { revision: task.revision }), errorStatus(400));
});

test('manual confirmation creates an independent snapshot; dirty edits require a new confirmation', () => {
  const state = createSeed();
  const task = draft(state);
  confirmTask(state, business, task.id, { revision: task.revision });
  assert.notEqual(task.confirmedVersion, task.editingVersion);
  assert.ok(task.confirmedAt);
  publishTask(state, business, task.id, { revision: task.revision });
  const publishedAt = task.publishedAt;
  saveTask(state, business, task.id, { revision: task.revision, card: DEMO_CARD });
  assert.equal(scoreCard(task.confirmedVersion).total, 20);
  assert.equal(scoreCard(task.editingVersion).total, 100);
  const publicTask = visibleStore(state, team()).tasks.find(item => item.id === task.id)!;
  assert.equal(scoreCard(publicTask.editingVersion).total, 20);
  assert.throws(() => publishTask(state, business, task.id, { revision: task.revision }), errorStatus(400));
  confirmTask(state, business, task.id, { revision: task.revision });
  assert.equal(scoreCard(task.confirmedVersion).total, 100);
  assert.equal(task.publishedAt, publishedAt);
  assert.equal(sortedPublished(state.tasks).some(item => item.id === task.id), true);
  const total = scoreCard(task.confirmedVersion).total;
  confirmTask(state, business, task.id, { revision: task.revision });
  assert.equal(scoreCard(task.confirmedVersion).total, total);
});

test('zero and twenty point publications are visible and accept proposals', () => {
  const state = createSeed();
  for (const [index, card] of [
    { ...emptyCard(), title: 'Задача без уточнений', industry: 'Услуги' }, lowCard(),
  ].entries()) {
    const task = draft(state, card);
    confirmTask(state, business, task.id, { revision: task.revision });
    publishTask(state, business, task.id, { revision: task.revision });
    assert.equal(scoreCard(task.confirmedVersion).total, index === 0 ? 0 : 20);
    assert.ok(visibleStore(state, team(5)).tasks.some(item => item.id === task.id));
    const proposal = createProposal(state, team(5), proposalBody(`low-score-${index}`, task.id));
    assert.equal(proposal.taskId, task.id);
  }
});

test('stale revisions fail without mutation; deleting confirmed details lowers the public score', () => {
  const state = createSeed();
  const task = state.tasks[4];
  const stale = task.revision;
  saveTask(state, business, task.id, { revision: stale, card: { ...DEMO_CARD, data: '' } });
  const before = structuredClone(task);
  for (const action of [saveTask, confirmTask, publishTask]) {
    assert.throws(() => action(state, business, task.id, { revision: stale, card: DEMO_CARD }), errorStatus(409));
    assert.deepEqual(task, before);
  }
  assert.equal(scoreCard(task.confirmedVersion).total, 100);
  confirmTask(state, business, task.id, { revision: task.revision });
  assert.equal(scoreCard(task.confirmedVersion).total, 80);
});

test('invalid save is atomic and preserves existing draft, timestamps and revision', () => {
  const state = createSeed();
  const task = draft(state);
  const before = structuredClone(task);
  assert.throws(() => saveTask(state, business, task.id, {
    revision: task.revision, card: DEMO_CARD, rawDescription: 123,
  }));
  assert.deepEqual(task, before);
});

test('proposal retry is idempotent but intentional variants from the same team are allowed', () => {
  const state = createSeed();
  const before = state.proposals.length;
  const first = createProposal(state, team(), proposalBody('request-repeat-1'));
  const retry = createProposal(state, team(), proposalBody('request-repeat-1'));
  assert.equal(first.id, retry.id);
  assert.equal(state.proposals.length, before + 1);
  const variant = createProposal(state, team(), { ...proposalBody('request-repeat-2'), idea: 'Другой вариант интерфейса.' });
  assert.notEqual(first.id, variant.id);
  assert.equal(state.proposals.length, before + 2);
  assert.equal(variant.teamId, first.teamId);
  const otherTeam = createProposal(state, team(2), proposalBody('request-repeat-1'));
  assert.notEqual(otherTeam.id, first.id);
  assert.throws(() => createProposal(state, team(), { ...proposalBody('request-invalid-1'), prototypeUrl: 'javascript:alert(1)' }));
  const privateTask = draft(state);
  assert.throws(() => createProposal(state, team(), proposalBody('request-private-1', privateTask.id)), errorStatus(400));
});

test('manual decisions support zero, one and multiple selected teams independently', () => {
  const state = createSeed();
  const a = createProposal(state, team(), proposalBody('decision-team-one'));
  const b = createProposal(state, team(2), proposalBody('decision-team-two'));
  assert.equal(state.proposals.filter(item => item.taskId === 'task-1' && item.status === 'selected').length, 0);
  decideProposal(state, business, a.id, { status: 'selected' });
  assert.equal(a.status, 'selected');
  assert.equal(b.status, 'submitted');
  decideProposal(state, business, b.id, { status: 'selected' });
  assert.equal(a.status, 'selected');
  assert.equal(b.status, 'selected');
  decideProposal(state, business, b.id, { status: 'rejected' });
  assert.equal(a.status, 'selected');
  decideProposal(state, business, a.id, { status: 'submitted' });
  assert.equal(a.decidedAt, null);
  assert.equal(state.proposals.filter(item => item.taskId === 'task-1' && item.status === 'selected').length, 0);
  assert.throws(() => decideProposal(state, team(), a.id, { status: 'selected' }), errorStatus(403));
});

test('only selected teams submit results; one selected variant is sufficient', () => {
  const state = createSeed();
  assert.throws(() => createMilestone(state, team(), milestoneBody('stage-unselected')), errorStatus(403));
  const first = createProposal(state, team(), proposalBody('variant-selected'));
  const second = createProposal(state, team(), proposalBody('variant-rejected'));
  decideProposal(state, business, first.id, { status: 'selected' });
  decideProposal(state, business, second.id, { status: 'rejected' });
  const stage = createMilestone(state, team(), milestoneBody('stage-with-variant'));
  assert.equal(stage.status, 'submitted');
  assert.equal(state.awards.length, 0);
  const repeat = createMilestone(state, team(), milestoneBody('stage-with-variant'));
  assert.equal(repeat.id, stage.id);
  assert.equal(state.milestones.length, 1);
  assert.throws(() => confirmMilestone(state, team(), stage.id), errorStatus(403));
});

test('confirmed milestone earns exactly ten once, survives replay and never changes task rating', () => {
  const state = createSeed();
  const proposal = createProposal(state, team(), proposalBody('award-proposal-one'));
  decideProposal(state, business, proposal.id, { status: 'selected' });
  const stage = createMilestone(state, team(), milestoneBody('award-stage-one'));
  const taskScore = scoreCard(state.tasks[0].confirmedVersion).total;
  confirmMilestone(state, business, stage.id);
  confirmMilestone(state, business, stage.id);
  const reloaded: Store = JSON.parse(JSON.stringify(state));
  confirmMilestone(reloaded, business, stage.id);
  assert.equal(stage.status, 'confirmed');
  assert.ok(stage.confirmedAt);
  assert.deepEqual(reloaded.awards, [{ teamId: 'team-1', milestoneId: stage.id, points: 10 }]);
  assert.equal(scoreCard(state.tasks[0].confirmedVersion).total, taskScore);
});

test('selection withdrawn before confirmation prevents a progress award', () => {
  const state = createSeed();
  const proposal = createProposal(state, team(), proposalBody('withdrawn-proposal'));
  decideProposal(state, business, proposal.id, { status: 'selected' });
  const stage = createMilestone(state, team(), milestoneBody('withdrawn-stage'));
  decideProposal(state, business, proposal.id, { status: 'rejected' });
  assert.throws(() => confirmMilestone(state, business, stage.id), errorStatus(409));
  assert.equal(state.awards.length, 0);
  assert.equal(stage.status, 'submitted');
});

test('public views redact raw/private drafts and expose only the requesting team proposals', () => {
  const state = createSeed();
  const privateTask = draft(state);
  const published = state.tasks[0];
  saveTask(state, business, published.id, { revision: published.revision, card: DEMO_CARD,
    rawDescription: 'Частный текст редактируемой версии.' });
  const publicView = visibleStore(state, team(3));
  assert.equal(publicView.tasks.some(item => item.id === privateTask.id), false);
  assert.deepEqual(publicView.drafts, []);
  const publicTask = publicView.tasks.find(item => item.id === published.id)!;
  assert.equal(publicTask.rawDescription, '');
  assert.equal(scoreCard(publicTask.editingVersion).total, 20);
  assert.deepEqual(publicTask.editingVersion, publicTask.confirmedVersion);
  assert.equal(publicView.proposals.every(item => item.teamId === 'team-3'), true);
  publicTask.editingVersion.context = 'Изменено снаружи';
  assert.notEqual(published.confirmedVersion?.context, publicTask.editingVersion.context);
  assert.equal(visibleStore(state, business).tasks.length, state.tasks.length);
  assert.equal(visibleStore(state, business).proposals.length, state.proposals.length);
});

test('role/ownership checks and card validation reject invalid writes', () => {
  const state = createSeed();
  const task = state.tasks[0];
  assert.throws(() => createTask(state, team(), { rawDescription: 'Новая задача', card: DEMO_CARD }), errorStatus(403));
  assert.throws(() => saveTask(state, { role: 'business', profileId: 'business-other' }, task.id,
    { revision: task.revision, card: DEMO_CARD }), errorStatus(403));
  assert.throws(() => cleanCard({ ...DEMO_CARD, users: 123 }), errorStatus(400));
  assert.throws(() => cleanCard({ ...DEMO_CARD, title: 'a'.repeat(161) }), errorStatus(400));
  assert.equal(cleanCard({ ...DEMO_CARD, title: '  Название  ' }).title, 'Название');
  const invalid = draft(state, { ...emptyCard(), title: 'не указано', industry: 'Услуги' });
  assert.throws(() => confirmTask(state, business, invalid.id, { revision: invalid.revision }), errorStatus(400));
});
