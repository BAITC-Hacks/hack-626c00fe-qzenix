import test from 'node:test';
import assert from 'node:assert/strict';
import { answersForQuestions, archiveAIContext, conversationHistory, freshAISession, mergeAIDraft, migrateLegacyAI, requestCard, sameAIContext } from '../shared/ai-session.js';
import { emptyCard } from '../shared/domain.js';
import type { AIQuestion } from '../shared/types.js';

const question = (id: string, text: string): AIQuestion => ({ id, field: 'successCriteria', question: text, reason: 'Уточнить проверку' });

test('question ids and shared fields never transfer an answer into a different question', () => {
  const old = [question('q1', 'Нужно ли распознавать речь?')];
  const next = [question('q1', 'Какая доля ошибок допустима?'), question('q2', 'Как проверить результат?')];
  assert.deepEqual(answersForQuestions(old, { q1: 'Да' }, next), { q1: '', q2: '' });
  assert.deepEqual(answersForQuestions(old, { q1: 'Да' }, [question('new-id', 'Нужно ли распознавать речь?')]), { 'new-id': 'Да' });
});

test('multi-round history keeps the original question beside every answer and allows clearing', () => {
  const old = question('q1', 'Нужно ли распознавать речь?');
  const next = question('q2', 'На каких языках?');
  const session = { ...freshAISession(), ...conversationHistory(freshAISession(), [old], { q1: 'Да' }) };
  const history = conversationHistory(session, [next], { q2: 'Русский и казахский' });
  assert.equal(history.historyAnswers.length, 2);
  assert.equal(history.historyAnswers[0].question, old.question);
  assert.equal(history.historyAnswers[0].answer, 'Да');
  const cleared = conversationHistory(history, [old], { q1: '' });
  assert.equal(cleared.historyAnswers.find(answer => answer.question === old.question)?.answer, '');
});

test('a changed task excludes old AI fields and keeps manual fields', () => {
  const session = { ...freshAISession(['data']), derivedFields: ['need' as const, 'context' as const] };
  const card = { ...emptyCard(), need: 'Старая задача', context: 'Старый контекст', data: 'Мой набор' };
  const changed = requestCard(card, session, true);
  assert.equal(changed.need, '');
  assert.equal(changed.context, '');
  assert.equal(changed.data, 'Мой набор');
  assert.equal(card.need, 'Старая задача');
  assert.equal(requestCard(card, session, false).need, 'Старая задача');
  assert.equal(sameAIContext({ raw: 'Первое описание', industry: 'Образование' }, 'Другое описание', 'Образование'), false);
});

test('AI refresh can improve generated fields while protecting edits made during the request', () => {
  const requested = { ...emptyCard(), need: 'Краткая потребность', data: 'CSV', users: '' };
  const current = { ...requested, users: 'Мой новый ручной ввод' };
  const result = mergeAIDraft(current, requested, { need: 'Уточнённая потребность', data: 'Чужие данные', users: 'Не применять' }, ['data']);
  assert.equal(result.card.need, 'Уточнённая потребность');
  assert.equal(result.card.data, 'CSV');
  assert.equal(result.card.users, 'Мой новый ручной ввод');
  assert.deepEqual(result.derivedFields, ['need']);
});

test('legacy migration preserves every old value in an accessible archive without reusing uncertain fields', () => {
  const card = { ...emptyCard(), industry: 'Образование', context: 'Неизвестно: вручную или AI', contact: 'demo@example.com' };
  const old = question('q1', 'Старый вопрос');
  const migrated = migrateLegacyAI('Старая задача', card, [old], { q1: 'Мой ответ' });
  assert.equal(migrated.needsRefresh, true);
  assert.equal(migrated.archives[0].card.context, card.context);
  assert.equal(migrated.archives[0].answers[0].answer, 'Мой ответ');
  assert.equal(migrated.archives[0].answers[0].question, old.question);
  assert.equal(requestCard(card, migrated, true).context, '');
  assert.equal(requestCard(card, migrated, true).contact, 'demo@example.com');
  assert.equal(migrated.historyAnswers.length, 0);
});

test('archiving keeps a detached snapshot when the working card changes', () => {
  const card = { ...emptyCard(), need: 'Исходное значение' };
  const archived = archiveAIContext(freshAISession(), 'Описание', card, [], {}, 'Новая задача');
  card.need = 'Новое значение';
  assert.equal(archived.card.need, 'Исходное значение');
});
