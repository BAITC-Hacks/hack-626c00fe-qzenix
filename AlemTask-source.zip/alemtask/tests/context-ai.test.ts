import test, { type TestContext } from 'node:test';
import assert from 'node:assert/strict';
import { analyze, localAnalyze } from '../server/ai.js';
import { emptyCard } from '../shared/domain.js';
import { DEMO_CARD } from '../shared/seed.js';
import type { AIInput, AIQuestion } from '../shared/types.js';

// Fetch is replaced for every adapter test. These fixtures never load .env or call OpenAI.
const initialInput = (): AIInput => ({ action: 'analyze', rawDescription: 'Мастерская принимает заказы в мессенджере.',
  industry: 'Услуги', answers: [] });
const question = (field: AIQuestion['field'], text: string, id = 'q1'): AIQuestion => ({
  id, field, question: text, reason: 'Нужно уточнить отсутствующие сведения',
});
const output = (questions: AIQuestion[] = []) => ({ questions,
  cardDraft: Object.fromEntries(Object.keys(emptyCard()).filter(key => key !== 'contact').map(key => [key, null])) as Record<string, string | null>,
  missingFields: [] as string[], warnings: [] as string[], evidence: [] as { field: string; quote: string }[],
});
function mockModel(t: TestContext, result: ReturnType<typeof output>) {
  process.env.OPENAI_API_KEY = 'test-only-not-a-real-api-key';
  process.env.OPENAI_MODEL = 'mock-context-model';
  const staged = { questions: result.questions, warnings: result.warnings,
    facts: Object.entries(result.cardDraft).filter(([, value]) => value !== null)
      .map(([field, value]) => ({ field, value, quote: result.evidence.find(item => item.field === field)?.quote ?? '' })) };
  const requests: Record<string, any>[] = [];
  t.mock.method(globalThis, 'fetch', async (request: string | URL | Request, init?: RequestInit) => {
    const body = init?.body ? String(init.body) : request instanceof Request ? await request.clone().text() : '{}';
    requests.push(JSON.parse(body));
    return new Response(JSON.stringify({ id: 'resp_context_test', object: 'response', created_at: 1,
      status: 'completed', model: 'mock-context-model', error: null, incomplete_details: null,
      output: [{ id: 'msg_context_test', type: 'message', role: 'assistant', status: 'completed',
        content: [{ type: 'output_text', text: JSON.stringify(staged), annotations: [] }] }],
    }), { status: 200, headers: { 'content-type': 'application/json' } });
  });
  return requests;
}
function payloadOf(requests: Record<string, any>[]) {
  assert.equal(requests.length, 2);
  return JSON.parse(requests[0].input.find((part: any) => part.role === 'user').content);
}

test('follow-up keeps the yes/no answer attached to its question and preserves manually edited details', async t => {
  const requests = mockModel(t, output());
  const asked = question('constraints', 'Нужно ли сохранить доступ для администратора?');
  const data: AIInput = { ...initialInput(), currentCard: { constraints: 'Срок — две недели. Доступ только для администратора.' },
    lockedFields: ['constraints'], previousQuestions: [asked],
    answers: [{ ...asked, answer: 'да' }] };
  const before = structuredClone(data);
  const result = await analyze(data);
  const payload = payloadOf(requests);
  assert.equal(payload.answers[0].question, asked.question);
  assert.equal(payload.answers[0].answer, 'да');
  assert.equal(payload.previousQuestions[0].question, asked.question);
  assert.equal(payload.currentCard.constraints, data.currentCard!.constraints);
  assert.equal(result.cardDraft.constraints, data.currentCard!.constraints);
  assert.deepEqual(data, before);
});

test('a short follow-up answer cannot replace a rich manual card field in local fallback', () => {
  const currentCard = { data: 'CSV с 100 обезличенными заказами за июнь.' };
  const result = localAnalyze({ ...initialInput(), currentCard,
    answers: [{ id: 'old-data', field: 'data', question: 'За какой месяц доступны эти данные?', answer: 'Только за июнь' }],
    lockedFields: ['data'] });
  assert.equal(result.cardDraft.data, currentCard.data);
});

test('near-identical questions from history are removed and repeated model ids do not collide', async t => {
  const previous = question('data', 'Какие данные заказов доступны для команды?', 'q1');
  const repeated = question('data', 'Какие данные заказов для команды доступны?', 'q1');
  const newQuestions = [question('constraints', 'Какой крайний срок передачи прототипа?', 'q1'),
    question('successTarget', 'Какое время обработки заказа будет приемлемым?', 'q1')];
  mockModel(t, output([repeated, ...newQuestions]));
  const result = await analyze({ ...initialInput(), previousQuestions: [previous],
    answers: [{ ...previous, answer: 'Пока неизвестно' }] });
  assert.equal(result.questions.some(item => item.field === 'data'), false);
  assert.deepEqual(result.questions.map(item => item.question), newQuestions.map(item => item.question));
  assert.equal(new Set(result.questions.map(item => item.id)).size, 2);
});

test('an unanswered relevant question remains available when the user retries without new information', async t => {
  const pending = question('data', 'Какие данные заказов доступны для команды?', 'original-id');
  mockModel(t, output([pending]));
  const result = await analyze({ ...initialInput(), previousQuestions: [pending], answers: [] });
  assert.equal(result.questions.length, 1);
  assert.equal(result.questions[0].question, pending.question);
  assert.equal(result.questions[0].field, pending.field);
});

test('a follow-up with no remaining questions is valid and does not invent three filler questions', async t => {
  mockModel(t, output());
  const result = await analyze({ ...initialInput(), currentCard: DEMO_CARD,
    previousQuestions: [question('data', 'Какие материалы доступны?')], answers: [] });
  assert.deepEqual(result.questions, []);
  assert.deepEqual(localAnalyze({ ...initialInput(), currentCard: DEMO_CARD }).questions, []);
});

test('the first analysis still rejects fewer than three distinct model questions', async t => {
  mockModel(t, output([question('data', 'Какие данные доступны?'),
    question('constraints', 'Какие сроки работы?')]));
  await assert.rejects(analyze(initialInput()), (error: unknown) =>
    typeof error === 'object' && error !== null && 'code' in error && error.code === 'AI_FORMAT');
});

test('a suggestion cannot use the assistant question itself as evidence of a user fact', async t => {
  const resultFixture = output();
  resultFixture.cardDraft.resultType = 'Telegram-бот';
  resultFixture.evidence = [{ field: 'resultType', quote: 'Telegram-бот' }];
  mockModel(t, resultFixture);
  const asked = question('resultType', 'Вам нужен Telegram-бот?');
  const result = await analyze({ ...initialInput(), previousQuestions: [asked],
    answers: [{ ...asked, answer: 'Не знаю' }] });
  assert.equal(result.cardDraft.resultType || '', '');
  assert.equal(result.summary?.includes('Telegram-бот') || false, false);
  assert.ok(result.warnings.some(warning => warning.includes('результат') || warning.includes('Результат')));
});

for (const [answer, supportedResult] of [
  ['Да', 'Нужен Telegram-бот.'],
  ['Нет', 'Telegram-бот не нужен.'],
]) {
  test(`an explicit ${answer} answer can ground the complete question-and-answer pair`, async t => {
    const asked = question('expectedResult', 'Вам нужен Telegram-бот?');
    const resultFixture = output();
    resultFixture.cardDraft.expectedResult = supportedResult;
    resultFixture.evidence = [{ field: 'expectedResult', quote: `Вопрос: ${asked.question} Ответ: ${answer}` }];
    mockModel(t, resultFixture);
    const result = await analyze({ ...initialInput(), previousQuestions: [asked],
      answers: [{ ...asked, answer }] });
    assert.equal(result.cardDraft.expectedResult, supportedResult);
    assert.ok(result.summary?.includes(supportedResult));
    assert.deepEqual(result.warnings, []);
  });
}

test('already answered substantive fields are not reasked as broad generic questions', async t => {
  const resultFixture = output([question('users', 'Кто будет пользоваться решением?'),
    question('constraints', 'К какому сроку нужен прототип?'),
    question('data', 'Какие примеры заказов доступны?')]);
  mockModel(t, resultFixture);
  const asked = question('users', 'Для кого создаётся решение?');
  const result = await analyze({ ...initialInput(), currentCard: { users: 'Администратор мастерской, который принимает заказы.' },
    previousQuestions: [asked], answers: [{ ...asked, answer: 'Администратор мастерской, который принимает заказы.' }] });
  assert.equal(result.questions.some(item => item.field === 'users'), false);
  assert.equal(result.questions.length, 2);
});

test('the question round receives facts extracted from the description and cannot reask those fields', async t => {
  const resultFixture = output([question('users', 'Кто будет пользоваться решением?'),
    question('constraints', 'К какому сроку нужен прототип?'),
    question('data', 'Какие примеры заказов доступны?')]);
  resultFixture.cardDraft.users = 'Администратор мастерской';
  resultFixture.evidence = [{ field: 'users', quote: 'Администратор мастерской' }];
  const requests = mockModel(t, resultFixture);
  const result = await analyze({ ...initialInput(),
    rawDescription: 'Администратор мастерской принимает заказы в мессенджере.' });
  assert.equal(requests.length, 2);
  const extractionPayload = JSON.parse(requests[0].input.find((part: any) => part.role === 'user').content);
  const questionPayload = JSON.parse(requests[1].input.find((part: any) => part.role === 'user').content);
  assert.equal(extractionPayload.currentCard.users, null);
  assert.equal(questionPayload.currentCard.users, 'Администратор мастерской');
  assert.equal(questionPayload.missingFields.includes('users'), false);
  assert.equal(result.cardDraft.users, 'Администратор мастерской');
  assert.equal(result.questions.some(item => item.field === 'users'), false);
});
