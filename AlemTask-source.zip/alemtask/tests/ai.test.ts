import test, { type TestContext } from 'node:test';
import assert from 'node:assert/strict';
import { analyze, errorForAI, localAnalyze } from '../server/ai.js';
import { emptyCard } from '../shared/domain.js';
import { DEMO_CARD } from '../shared/seed.js';
import type { AIInput } from '../shared/types.js';

// These values exist only in this isolated test process. No .env is loaded and no real key is read.
const configureMock = () => {
  process.env.OPENAI_API_KEY = 'test-only-not-a-real-api-key';
  process.env.OPENAI_MODEL = 'mock-test-model';
};
const input = (): AIInput => ({ action: 'analyze', rawDescription: 'Хотим автоматизировать обработку заявок.',
  industry: 'Образование', answers: [] });
const threeQuestions = () => [
  { id: 'q1', field: 'context', question: 'Как сейчас обрабатываются заявки?', reason: 'Не описан процесс' },
  { id: 'q2', field: 'data', question: 'Какие примеры заявок доступны?', reason: 'Не указаны данные' },
  { id: 'q3', field: 'successCriteria', question: 'Как будет проверен результат?', reason: 'Не определена проверка' },
];
function structuredOutput() {
  return { questions: threeQuestions(),
    cardDraft: Object.fromEntries(Object.keys(emptyCard()).filter(key => key !== 'contact').map(key => [key, null])) as Record<string, string | null>,
    missingFields: ['context', 'data', 'successCriteria'], warnings: [] as string[], evidence: [] as { field: string; quote: string }[] };
}
function responseFor(result = structuredOutput(), status = 'completed') {
  // One fixture can answer both schemas; each parser keeps only its stage's fields.
  const staged = { questions: result.questions, warnings: result.warnings,
    facts: Object.entries(result.cardDraft).filter(([, value]) => value !== null)
      .map(([field, value]) => ({ field, value, quote: result.evidence.find(item => item.field === field)?.quote ?? '' })) };
  return { id: 'resp_test', object: 'response', created_at: 1, status, model: 'mock-test-model',
    output: [{ id: 'msg_test', type: 'message', role: 'assistant', status: 'completed',
      content: [{ type: 'output_text', text: JSON.stringify(staged), annotations: [] }] }],
    error: null, incomplete_details: status === 'incomplete' ? { reason: 'max_output_tokens' } : null };
}
function mockResponse(t: TestContext, response: unknown) {
  configureMock();
  const requests: Record<string, any>[] = [];
  t.mock.method(globalThis, 'fetch', async (request: string | URL | Request, init?: RequestInit) => {
    const raw = init?.body ? String(init.body) : request instanceof Request ? await request.clone().text() : '{}';
    requests.push(JSON.parse(raw));
    return new Response(JSON.stringify(response), { status: 200,
      headers: { 'content-type': 'application/json', 'x-request-id': 'test-request' } });
  });
  return requests;
}
const codeIs = (code: string) => (error: unknown) =>
  typeof error === 'object' && error !== null && 'code' in error && error.code === code;

test('local analysis asks at least three relevant questions and preserves manual information', () => {
  const original = { ...input(), currentCard: { context: 'Заявки записывает администратор.', contact: 'demo@example.com' },
    answers: [{ id: 'answer-data', field: 'data' as const, answer: 'Синтетический CSV из 100 заявок.' }] };
  const before = structuredClone(original);
  const result = localAnalyze(original);
  assert.equal(result.mode, 'local');
  assert.ok(result.questions.length >= 3);
  assert.equal(new Set(result.questions.map(question => question.question)).size, result.questions.length);
  assert.equal(result.questions.some(question => question.field === 'context'), false);
  assert.equal(result.cardDraft.data, 'Синтетический CSV из 100 заявок.');
  assert.equal(result.cardDraft.contact, 'demo@example.com');
  assert.equal(result.missingFields.includes('contact'), false);
  assert.equal(result.cardDraft.constraints, '');
  assert.deepEqual(original, before);
  assert.equal(localAnalyze({ ...input(), currentCard: DEMO_CARD }).questions.length, 0);
});

test('upstream errors map to safe user-facing codes without copying provider details', () => {
  const cases: [unknown, string][] = [
    [{ status: 401, message: 'PRIVATE_PROVIDER_DETAIL' }, 'AI_AUTH'],
    [{ status: 403 }, 'AI_PERMISSION'], [{ status: 404 }, 'AI_MODEL'], [{ status: 429 }, 'AI_LIMIT'],
    [{ name: 'APIConnectionTimeoutError' }, 'AI_TIMEOUT'], [new SyntaxError('PRIVATE_PROVIDER_DETAIL'), 'AI_FORMAT'],
    [{ status: 500 }, 'AI_UNAVAILABLE'], [null, 'AI_UNAVAILABLE'],
  ];
  for (const [error, code] of cases) {
    const safe = errorForAI(error);
    assert.equal(safe.code, code);
    assert.equal(safe.message.includes('PRIVATE_PROVIDER_DETAIL'), false);
  }
});

test('real adapter request redacts contact across description, all card values, industry and answers', async t => {
  const requests = mockResponse(t, responseFor());
  const data: AIInput = { ...input(), rawDescription: 'Пишите на raw@example.net по заявкам.',
    industry: 'Услуги branch@example.net',
    currentCard: { contact: '+7 700 000 00 00', context: 'Заявки отправляют на office@example.net.',
      need: 'Обратная связь: +7 700 000 00 00', users: 'Администратор users@example.net' },
    answers: [{ id: 'q-data', field: 'data', answer: 'CSV доступен через data@example.net.' },
      { id: 'q-contact', field: 'contact', answer: '+7 700 000 00 00' }] };
  const result = await analyze(data);
  assert.equal(requests.length, 2);
  for (const request of requests) {
    assert.equal(request.store, false);
    assert.equal(request.model, 'mock-test-model');
    const outward = request.input.find((part: any) => part.role === 'user').content as string;
    for (const secret of ['raw@example.net', 'branch@example.net', 'office@example.net', 'users@example.net', 'data@example.net', '+7 700 000 00 00']) {
      assert.equal(outward.includes(secret), false, `Contact leaked: ${secret}`);
    }
  }
  const outward = requests[0].input.find((part: any) => part.role === 'user').content as string;
  const payload = JSON.parse(outward);
  assert.equal(Object.hasOwn(payload.currentCard, 'contact'), false);
  assert.equal(payload.answers.some((answer: any) => answer.field === 'contact'), false);
  assert.equal(result.cardDraft.contact, '+7 700 000 00 00');
  assert.equal(result.cardDraft.context, 'Заявки отправляют на office@example.net.');
  assert.equal(result.missingFields.includes('contact'), false);
  assert.equal(result.mode, 'openai');
});

test('compose extracts supported facts in one call without requesting a new question round', async t => {
  const output = structuredOutput();
  output.cardDraft.need = 'Автоматизировать обработку заявок.';
  output.evidence = [{ field: 'need', quote: 'автоматизировать обработку заявок' }];
  const requests = mockResponse(t, responseFor(output));
  const result = await analyze({ ...input(), action: 'compose' });
  assert.equal(requests.length, 1);
  assert.equal(result.cardDraft.need, 'Автоматизировать обработку заявок.');
  assert.deepEqual(result.questions, []);
});

test('adapter accepts supported suggestions, rejects unsupported ones and preserves existing edits', async t => {
  const output = structuredOutput();
  output.cardDraft.need = 'Автоматизировать обработку заявок.';
  output.cardDraft.users = 'Сотрудник отдела продаж';
  output.cardDraft.context = 'Другая формулировка процесса';
  output.evidence = [{ field: 'need', quote: 'автоматизировать обработку заявок' }];
  mockResponse(t, responseFor(output));
  const result = await analyze({ ...input(), currentCard: { context: 'Мой сохранённый процесс', contact: 'demo@example.com' } });
  assert.equal(result.cardDraft.need, 'Автоматизировать обработку заявок.');
  assert.equal(result.cardDraft.users, '');
  assert.equal(result.cardDraft.context, 'Мой сохранённый процесс');
  assert.equal(result.cardDraft.contact, 'demo@example.com');
  assert.ok(result.warnings.some(warning => warning.includes('Пользователи')));
  assert.ok(result.missingFields.includes('users'));
});

test('duplicate questions cannot satisfy the three-question minimum', async t => {
  const output = structuredOutput();
  output.questions = [threeQuestions()[0], { ...threeQuestions()[0], id: 'q-duplicate' }, threeQuestions()[1]];
  mockResponse(t, responseFor(output));
  await assert.rejects(analyze(input()), codeIs('AI_FORMAT'));
});

test('incomplete response is rejected before changing user data', async t => {
  mockResponse(t, responseFor(structuredOutput(), 'incomplete'));
  const original = input();
  const before = structuredClone(original);
  await assert.rejects(analyze(original), codeIs('AI_INCOMPLETE'));
  assert.deepEqual(original, before);
});

test('model refusal produces an explicit safe error', async t => {
  const response = responseFor();
  const refusal = { ...response, output: [{ id: 'msg_refusal', type: 'message', role: 'assistant', status: 'completed',
    content: [{ type: 'refusal', refusal: 'Cannot comply.' }] }] };
  mockResponse(t, refusal);
  await assert.rejects(analyze(input()), codeIs('AI_REFUSAL'));
});
