import { spawnSync } from 'node:child_process';

// Build-first preview avoids Vite's dev dependency optimizer in restricted Windows environments.
console.log('AlemTask: сборка и локальный предпросмотр. После изменений перезапустите pnpm dev; HMR отключён.');
const build = spawnSync(process.execPath, ['scripts/build.mjs'], {
  stdio: 'inherit', windowsHide: true,
});
if (build.error) {
  console.error('Не удалось запустить сборку:', build.error.message);
  process.exit(1);
}
if (build.status !== 0) process.exit(build.status || 1);

if (!process.argv.includes('--production')) process.argv.push('--production');
await import('./run.mjs');
