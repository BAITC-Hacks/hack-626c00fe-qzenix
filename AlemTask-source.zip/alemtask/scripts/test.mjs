import {spawnSync} from 'node:child_process';
import {readdirSync} from 'node:fs';
import {compile} from './compile.mjs';
compile();
const files=readdirSync('.runtime/tests').filter(p=>p.endsWith('.test.js')).map(p=>'.runtime/tests/'+p);
const result=spawnSync(process.execPath,['--test',...files],{stdio:'inherit',windowsHide:true});process.exit(result.status||0);
