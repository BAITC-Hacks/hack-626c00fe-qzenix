import {compile} from './compile.mjs';
compile();await import('../.runtime/server/reset.js');
