import {spawnSync} from 'node:child_process';
export function compile(){const result=spawnSync(process.execPath,['node_modules/typescript/bin/tsc','-p','tsconfig.server.json'],{stdio:'inherit',windowsHide:true});if(result.status!==0)process.exit(result.status||1);}
