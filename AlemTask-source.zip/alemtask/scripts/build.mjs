import {spawnSync} from 'node:child_process';
import {build} from 'vite';
const check=spawnSync(process.execPath,['node_modules/typescript/bin/tsc','--noEmit'],{stdio:'inherit',windowsHide:true});
if(check.status!==0)process.exit(check.status||1);
await build({configLoader:'native'});
